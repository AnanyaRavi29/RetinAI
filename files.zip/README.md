# 🐄 DA5402 — Cattle Muzzle Biometrics Pipeline

A fully reproducible DVC pipeline for cattle identification via muzzle images.
Implements three distinct model architectures with all experiments tracked via DVC.

---

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Place dataset into data/raw/
#    Each subfolder = one cattle ID
#    data/raw/cow_001/img1.jpg
#    data/raw/cow_002/img1.jpg  ...

# 3. Run the automated setup (initialises git, DVC, runs all 3 experiments)
bash setup_dvc.sh

# OR manually run one experiment at a time:
dvc repro
```

---

## Project Structure

```
cattle-biometrics/
├── data/
│   ├── raw/              ← your dataset (DVC-tracked via data/raw.dvc)
│   ├── processed/        ← resized, split (DVC-tracked)
│   └── transformed/      ← HOG features or augmented images (DVC-tracked)
├── models/
│   └── model_artifact/   ← model.pkl or model.pt (DVC-tracked)
├── metrics/
│   ├── scores.json       ← DVC metrics (macro F1, accuracy, …)
│   └── train_history.json
├── plots/
│   ├── confusion_matrix.csv   ← dvc plots
│   └── per_class_f1.csv
├── notebooks/
│   └── inference.ipynb   ← test any model interactively
├── src/
│   ├── prepare.py        ← Stage 1: resize + 90/10 split
│   ├── transform.py      ← Stage 2: HOG extraction or augmentation
│   ├── train.py          ← Stage 3: SVM / MLP / EfficientNet
│   └── evaluate.py       ← Stage 4: Macro F1 + DVC plots
├── params.yaml           ← ALL hyperparameters (no hardcoding)
├── dvc.yaml              ← Pipeline definition
└── requirements.txt
```

---

## Running Experiments

Switch experiments by changing **one line** in `params.yaml`:

```yaml
experiment:
  type: transfer_learning   # traditional_ml | mlp | transfer_learning
```

Then run:
```bash
dvc repro
```
DVC will only re-run stages whose inputs/params changed.

---

## The 3 Experiments

| Experiment | Feature | Model | Expected F1 |
|---|---|---|---|
| `traditional_ml` | HOG + Color Hist | SVM (RBF, C=10) | 0.50–0.75 |
| `mlp` | HOG + Color Hist | 3-layer MLP | 0.60–0.80 |
| `transfer_learning` | Raw pixels | EfficientNet-B2 fine-tuned | **0.85–0.95+** |

---

## DVC Commands Reference

```bash
# View current metrics
dvc metrics show

# Compare two experiments
dvc metrics diff exp-v1-traditional-ml exp-v3-transfer-learning

# Open plots in browser
dvc plots show

# Compare plots across experiments
dvc plots diff exp-v1-traditional-ml exp-v2-mlp exp-v3-transfer-learning

# Reproduce a specific past experiment exactly
git checkout exp-v1-traditional-ml
dvc checkout
dvc repro

# See all experiment tags
git tag -l

# See pipeline DAG
dvc dag
```

---

## Improving Macro F1 (to reach > 0.90)

1. **Use `transfer_learning`** — this is the critical one. EfficientNet-B2 is already set up.
2. **Increase epochs**: set `transfer_learning.total_epochs: 60`
3. **More augmentation**: set `transform.augment_factor: 5`
4. **Lower backbone LR**: `transfer_learning.lr_backbone: 0.00002`
5. **Use TTA** at inference time: see the inference notebook, Cell 7
6. **Check your class balance**: classes with very few images will hurt F1.
   The pipeline uses `class_weight: balanced` and label smoothing.

---

## Grading Checklist

- [x] DVC versioning (`dvc add data/raw`, git tags per experiment)
- [x] 2+ versions of processed dataset (`data-v1` = resized, `data-v2` = augmented)
- [x] `dvc.yaml` with `prepare → transform → train → evaluate` stages
- [x] `params.yaml` for all hyperparameters (zero hardcoding)
- [x] 3 model types: SVM, MLP, EfficientNet
- [x] `metrics/scores.json` with Macro F1 for `dvc metrics show`
- [x] `plots/` CSV files for `dvc plots show`
- [x] Every experiment reproducible via `dvc repro`
- [x] AI-assistance comments on every assisted block
