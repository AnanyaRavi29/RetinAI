"""
Stage 2 – transform.py
- traditional_ml / mlp  → HOG feature extraction (+ optional BoVW for SIFT)
- transfer_learning     → Augmented image copies saved to disk
All parameters come from params.yaml.
"""
# Assisted by Claude (Anthropic)

import json
import os
import random
import shutil
from pathlib import Path

import numpy as np
import yaml
from PIL import Image, ImageEnhance, ImageFilter
from skimage.feature import hog
from tqdm import tqdm


def load_params() -> dict:
    with open("params.yaml") as f:
        return yaml.safe_load(f)


# ─── Feature Extraction ───────────────────────────────────────────────────────

def extract_hog_features(img_array: np.ndarray, hog_cfg: dict) -> np.ndarray:
    """Extract HOG feature vector from an RGB image array."""
    features = hog(
        img_array,
        orientations=hog_cfg["orientations"],
        pixels_per_cell=tuple(hog_cfg["pixels_per_cell"]),
        cells_per_block=tuple(hog_cfg["cells_per_block"]),
        channel_axis=hog_cfg["channel_axis"],
        feature_vector=True,
    )
    return features


def extract_color_histogram(img_array: np.ndarray, bins: int = 64) -> np.ndarray:
    """Per-channel color histogram, normalised."""
    hist = []
    for ch in range(3):
        h, _ = np.histogram(img_array[:, :, ch], bins=bins, range=(0, 256))
        hist.append(h / (h.sum() + 1e-8))
    return np.concatenate(hist)


def extract_features_for_split(
    split_dir: Path, class_map: dict, hog_cfg: dict, color_bins: int
) -> tuple[np.ndarray, np.ndarray]:
    """Walk split_dir and return (feature_matrix, label_array)."""
    X, y = [], []
    for class_name in sorted(class_map.keys()):
        class_path = split_dir / class_name
        if not class_path.exists():
            continue
        label_idx = class_map[class_name]
        for img_path in sorted(class_path.iterdir()):
            img = Image.open(img_path).convert("RGB")
            arr = np.array(img)
            hog_feat = extract_hog_features(arr, hog_cfg)
            color_feat = extract_color_histogram(arr, color_bins)
            feat = np.concatenate([hog_feat, color_feat])
            X.append(feat)
            y.append(label_idx)
    return np.array(X, dtype=np.float32), np.array(y, dtype=np.int64)


# ─── Augmentation ─────────────────────────────────────────────────────────────

def augment_image(img: Image.Image, strength: str = "strong") -> list[Image.Image]:
    """Return a list of augmented PIL images (excluding original)."""
    augmented = []

    ops_light = [
        lambda i: i.transpose(Image.FLIP_LEFT_RIGHT),
        lambda i: i.rotate(random.uniform(-15, 15), fillcolor=(128, 128, 128)),
        lambda i: ImageEnhance.Brightness(i).enhance(random.uniform(0.8, 1.2)),
    ]

    ops_strong = ops_light + [
        lambda i: i.rotate(random.uniform(-30, 30), fillcolor=(128, 128, 128)),
        lambda i: ImageEnhance.Contrast(i).enhance(random.uniform(0.7, 1.4)),
        lambda i: ImageEnhance.Saturation(i).enhance(random.uniform(0.6, 1.6)),
        lambda i: i.filter(ImageFilter.GaussianBlur(radius=random.uniform(0, 1.5))),
        lambda i: _random_crop_resize(i),
        lambda i: i.transpose(Image.FLIP_TOP_BOTTOM),
    ]

    ops = ops_strong if strength == "strong" else ops_light

    # Each augmented image = random composition of 2-3 ops
    for _ in range(3):
        chosen = random.sample(ops, k=random.randint(2, 3))
        aug = img.copy()
        for op in chosen:
            try:
                aug = op(aug)
            except Exception:
                pass
        augmented.append(aug)

    return augmented


def _random_crop_resize(img: Image.Image) -> Image.Image:
    w, h = img.size
    crop_frac = random.uniform(0.75, 0.95)
    cw, ch = int(w * crop_frac), int(h * crop_frac)
    left = random.randint(0, w - cw)
    top = random.randint(0, h - ch)
    return img.crop((left, top, left + cw, top + ch)).resize((w, h), Image.LANCZOS)


def augment_split(
    split_dir: Path,
    out_dir: Path,
    factor: int,
    strength: str,
    seed: int,
) -> None:
    """Copy originals + add augmented copies into out_dir."""
    random.seed(seed)
    for class_dir in tqdm(sorted(split_dir.iterdir()), desc=f"  Augmenting {split_dir.name}"):
        if not class_dir.is_dir():
            continue
        out_class = out_dir / class_dir.name
        out_class.mkdir(parents=True, exist_ok=True)
        for img_path in sorted(class_dir.iterdir()):
            # Copy original
            shutil.copy2(img_path, out_class / img_path.name)
            # Add augmented copies
            img = Image.open(img_path).convert("RGB")
            for aug_idx in range(factor):
                augs = augment_image(img, strength=strength)
                for a_idx, aug_img in enumerate(augs[:1]):  # 1 aug per factor step
                    out_name = f"{img_path.stem}_aug{aug_idx}_{a_idx}.jpg"
                    aug_img.save(out_class / out_name, "JPEG", quality=90)


# ─── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    params = load_params()
    exp_type = params["experiment"]["type"]
    proc_dir = Path("data/processed")
    trans_dir = Path("data/transformed")

    if trans_dir.exists():
        shutil.rmtree(trans_dir)
    trans_dir.mkdir(parents=True)

    with open(proc_dir / "class_map.json") as f:
        class_map = json.load(f)

    # ── Feature-based path (traditional_ml + mlp) ────────────────────────
    if exp_type in ("traditional_ml", "mlp"):
        hog_cfg = params["transform"]["hog"]
        color_bins = params["transform"]["color_hist"]["bins"]
        print(f"[transform] Extracting HOG + color histogram features for {exp_type}...")

        for split in ("train", "val", "test"):
            split_dir = proc_dir / split
            print(f"  Processing {split}...")
            X, y = extract_features_for_split(split_dir, class_map, hog_cfg, color_bins)
            np.savez_compressed(trans_dir / f"{split}_features.npz", X=X, y=y)
            print(f"  {split}: X={X.shape}, y={y.shape}")

        # Save feature dimension info
        info = {"feature_dim": int(X.shape[1]), "num_classes": len(class_map)}
        with open(trans_dir / "feature_info.json", "w") as f:
            json.dump(info, f, indent=2)
        print(f"[transform] Done. Feature dim: {X.shape[1]}")

    # ── Image-based path (transfer_learning) ─────────────────────────────
    elif exp_type == "transfer_learning":
        aug_cfg = params["transform"]
        strength = params["transfer_learning"]["augment_strength"]
        factor = aug_cfg["augment_factor"]
        seed = params["base"]["random_seed"]

        print(f"[transform] Augmenting images (factor={factor}, strength={strength})...")

        # Train gets augmented, val and test get original copies only
        augment_split(
            split_dir=proc_dir / "train",
            out_dir=trans_dir / "train",
            factor=factor,
            strength=strength,
            seed=seed,
        )

        for split in ("val", "test"):
            print(f"  Copying {split} (no augmentation)...")
            shutil.copytree(proc_dir / split, trans_dir / split)

        # Copy class_map
        shutil.copy2(proc_dir / "class_map.json", trans_dir / "class_map.json")

        # Count
        total_train = sum(
            len(list(d.iterdir()))
            for d in (trans_dir / "train").iterdir() if d.is_dir()
        )
        print(f"[transform] Done. Augmented train size: {total_train} images.")

    else:
        raise ValueError(f"Unknown experiment type: {exp_type}")


if __name__ == "__main__":
    main()
