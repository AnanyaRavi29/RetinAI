"""
Stage 1 – prepare.py
Filters classes, resizes images, performs stratified 90/10 split.
All parameters come from params.yaml.
"""
# Assisted by Claude (Anthropic)

import json
import os
import shutil
from pathlib import Path

import numpy as np
import yaml
from PIL import Image
from sklearn.model_selection import train_test_split
from tqdm import tqdm


def load_params() -> dict:
    with open("params.yaml") as f:
        return yaml.safe_load(f)


def collect_samples(raw_dir: Path, min_images: int) -> tuple[list, list]:
    """Walk raw_dir, collect (image_path, label) pairs for qualifying classes."""
    images, labels = [], []
    skipped = []

    for class_dir in sorted(raw_dir.iterdir()):
        if not class_dir.is_dir():
            continue
        imgs = [
            p for p in class_dir.iterdir()
            if p.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
        ]
        if len(imgs) < min_images:
            skipped.append((class_dir.name, len(imgs)))
            continue
        for img_path in imgs:
            images.append(img_path)
            labels.append(class_dir.name)

    print(f"  Loaded {len(images)} images across {len(set(labels))} classes.")
    if skipped:
        print(f"  Skipped {len(skipped)} classes with < {min_images} images: "
              f"{[s[0] for s in skipped[:10]]}")
    return images, labels


def resize_and_save(src: Path, dst: Path, size: tuple[int, int]) -> None:
    """Resize image to size (W, H) and save as JPEG."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    img = Image.open(src).convert("RGB")
    img = img.resize(size, Image.LANCZOS)
    img.save(dst, "JPEG", quality=95)


def split_and_copy(
    images: list,
    labels: list,
    processed_dir: Path,
    test_size: float,
    val_size: float,
    image_size: tuple[int, int],
    seed: int,
) -> None:
    """Stratified split → copy resized images into train/val/test."""

    # First: carve out test set
    idx = list(range(len(images)))
    idx_trainval, idx_test = train_test_split(
        idx, test_size=test_size, stratify=labels, random_state=seed
    )

    labels_trainval = [labels[i] for i in idx_trainval]

    # Second: split train/val from the trainval pool
    idx_train, idx_val = train_test_split(
        idx_trainval,
        test_size=val_size,
        stratify=labels_trainval,
        random_state=seed,
    )

    splits = {"train": idx_train, "val": idx_val, "test": idx_test}
    for split_name, indices in splits.items():
        print(f"  {split_name}: {len(indices)} images")
        for i in tqdm(indices, desc=f"  Copying {split_name}", leave=False):
            src = images[i]
            label = labels[i]
            dst = processed_dir / split_name / label / src.name
            # Ensure unique filenames (rare collision guard)
            if dst.exists():
                stem = dst.stem
                dst = dst.with_stem(f"{stem}_{i}")
            resize_and_save(src, dst, image_size)

    # Save class map: label string → integer index
    class_names = sorted(set(labels))
    class_map = {name: idx for idx, name in enumerate(class_names)}
    with open(processed_dir / "class_map.json", "w") as f:
        json.dump(class_map, f, indent=2)
    print(f"  Saved class_map.json with {len(class_map)} classes.")


def main() -> None:
    params = load_params()
    base = params["base"]
    prep = params["prepare"]

    raw_dir = Path("data/raw")
    processed_dir = Path("data/processed")

    # Clean previous processed data for a clean run
    if processed_dir.exists():
        shutil.rmtree(processed_dir)
    processed_dir.mkdir(parents=True)

    image_size = tuple(prep["image_size"])  # (W, H)

    print("[prepare] Collecting samples...")
    images, labels = collect_samples(raw_dir, base["min_images_per_class"])

    print("[prepare] Splitting and copying resized images...")
    split_and_copy(
        images=images,
        labels=labels,
        processed_dir=processed_dir,
        test_size=base["test_size"],
        val_size=base["val_size"],
        image_size=image_size,
        seed=base["random_seed"],
    )

    # Summary stats for DVC metrics
    class_counts = {}
    for label in labels:
        class_counts[label] = class_counts.get(label, 0) + 1

    summary = {
        "total_images": len(images),
        "num_classes": len(set(labels)),
        "image_size": list(image_size),
        "min_class_size": min(class_counts.values()),
        "max_class_size": max(class_counts.values()),
    }
    print(f"\n[prepare] Done. Summary: {summary}")


if __name__ == "__main__":
    main()
