"""
Stage 3 – train.py
Trains the model specified by experiment.type in params.yaml.
Saves model artifact and training history metrics.
"""
# Assisted by Claude (Anthropic)

import json
import os
import pickle
import random
from pathlib import Path

import numpy as np
import yaml


def load_params() -> dict:
    with open("params.yaml") as f:
        return yaml.safe_load(f)


def set_seeds(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except ImportError:
        pass


# ─────────────────────────────────────────────────────────────────────────────
# TRADITIONAL ML: HOG + SVM
# ─────────────────────────────────────────────────────────────────────────────

def train_traditional_ml(params: dict, trans_dir: Path, model_dir: Path) -> dict:
    from sklearn.decomposition import PCA
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.svm import SVC

    cfg = params["traditional_ml"]
    svm_cfg = cfg["svm"]
    pca_cfg = cfg["pca"]

    print("[train] Loading HOG features...")
    train_data = np.load(trans_dir / "train_features.npz")
    val_data = np.load(trans_dir / "val_features.npz")

    X_train, y_train = train_data["X"], train_data["y"]
    X_val, y_val = val_data["X"], val_data["y"]

    print(f"  Train: {X_train.shape}, Val: {X_val.shape}")

    steps = [("scaler", StandardScaler())]
    if pca_cfg["use_pca"]:
        n_comp = min(pca_cfg["n_components"], X_train.shape[1], X_train.shape[0])
        steps.append(("pca", PCA(n_components=n_comp, random_state=params["base"]["random_seed"])))
    steps.append((
        "svm",
        SVC(
            C=svm_cfg["C"],
            kernel=svm_cfg["kernel"],
            gamma=svm_cfg["gamma"],
            class_weight=svm_cfg["class_weight"],
            probability=True,
            random_state=params["base"]["random_seed"],
        ),
    ))

    pipeline = Pipeline(steps)
    print("[train] Fitting SVM pipeline...")
    pipeline.fit(X_train, y_train)

    val_acc = pipeline.score(X_val, y_val)
    print(f"  Val accuracy: {val_acc:.4f}")

    # Save model
    model_dir.mkdir(parents=True, exist_ok=True)
    with open(model_dir / "model.pkl", "wb") as f:
        pickle.dump(pipeline, f)
    print(f"[train] Model saved → {model_dir / 'model.pkl'}")

    history = {"val_accuracy": [val_acc], "epoch": [0]}
    return history


# ─────────────────────────────────────────────────────────────────────────────
# SHALLOW NN: MLP on HOG features
# ─────────────────────────────────────────────────────────────────────────────

def train_mlp(params: dict, trans_dir: Path, model_dir: Path, class_map: dict) -> dict:
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader, TensorDataset
    from sklearn.preprocessing import StandardScaler
    from sklearn.utils.class_weight import compute_class_weight

    cfg = params["mlp"]
    seed = params["base"]["random_seed"]
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[train] Using device: {device}")

    # Load features
    train_data = np.load(trans_dir / "train_features.npz")
    val_data = np.load(trans_dir / "val_features.npz")
    X_train, y_train = train_data["X"].astype(np.float32), train_data["y"]
    X_val, y_val = val_data["X"].astype(np.float32), val_data["y"]

    # Normalise
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_val = scaler.transform(X_val)

    num_classes = len(class_map)
    input_dim = X_train.shape[1]

    # Class weights
    class_weights = None
    if cfg["class_weight"] == "balanced":
        cw = compute_class_weight("balanced", classes=np.unique(y_train), y=y_train)
        class_weights = torch.tensor(cw, dtype=torch.float32).to(device)

    # Build MLP
    class MLP(nn.Module):
        def __init__(self):
            super().__init__()
            layers = []
            in_dim = input_dim
            for h in cfg["hidden_sizes"]:
                layers.append(nn.Linear(in_dim, h))
                if cfg["batch_norm"]:
                    layers.append(nn.BatchNorm1d(h))
                layers.append(nn.GELU())
                layers.append(nn.Dropout(cfg["dropout"]))
                in_dim = h
            layers.append(nn.Linear(in_dim, num_classes))
            self.net = nn.Sequential(*layers)

        def forward(self, x):
            return self.net(x)

    model = MLP().to(device)
    criterion = nn.CrossEntropyLoss(weight=class_weights)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=cfg["lr"], weight_decay=cfg["weight_decay"]
    )

    if cfg["lr_scheduler"] == "cosine":
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=cfg["epochs"]
        )
    else:
        scheduler = None

    # DataLoaders
    def make_loader(X, y, shuffle=True):
        ds = TensorDataset(
            torch.tensor(X, dtype=torch.float32),
            torch.tensor(y, dtype=torch.long),
        )
        return DataLoader(ds, batch_size=cfg["batch_size"], shuffle=shuffle, num_workers=0)

    train_loader = make_loader(X_train, y_train, shuffle=True)
    val_loader = make_loader(X_val, y_val, shuffle=False)

    history = {"epoch": [], "train_loss": [], "val_loss": [], "val_accuracy": []}
    best_val_acc = 0.0
    patience_counter = 0

    for epoch in range(1, cfg["epochs"] + 1):
        model.train()
        running_loss = 0.0
        for xb, yb in train_loader:
            xb, yb = xb.to(device), yb.to(device)
            optimizer.zero_grad()
            loss = criterion(model(xb), yb)
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * len(xb)
        if scheduler:
            scheduler.step()

        # Validation
        model.eval()
        val_loss, correct, total = 0.0, 0, 0
        with torch.no_grad():
            for xb, yb in val_loader:
                xb, yb = xb.to(device), yb.to(device)
                logits = model(xb)
                val_loss += criterion(logits, yb).item() * len(xb)
                correct += (logits.argmax(1) == yb).sum().item()
                total += len(yb)
        val_acc = correct / total
        val_loss /= total
        train_loss = running_loss / len(X_train)

        history["epoch"].append(epoch)
        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["val_accuracy"].append(val_acc)

        if epoch % 5 == 0 or epoch == 1:
            print(f"  Epoch {epoch:3d}/{cfg['epochs']} | "
                  f"train_loss={train_loss:.4f} | val_loss={val_loss:.4f} | val_acc={val_acc:.4f}")

        # Early stopping
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            patience_counter = 0
            model_dir.mkdir(parents=True, exist_ok=True)
            torch.save({"model_state": model.state_dict(), "scaler": scaler,
                        "config": cfg, "input_dim": input_dim, "num_classes": num_classes},
                       model_dir / "model.pt")
        else:
            patience_counter += 1
            if patience_counter >= cfg["early_stopping_patience"]:
                print(f"  Early stopping at epoch {epoch}")
                break

    print(f"[train] Best val accuracy: {best_val_acc:.4f}")
    return history


# ─────────────────────────────────────────────────────────────────────────────
# TRANSFER LEARNING: Fine-tuned EfficientNet / ResNet
# ─────────────────────────────────────────────────────────────────────────────

def train_transfer_learning(params: dict, trans_dir: Path, model_dir: Path, class_map: dict) -> dict:
    import torch
    import torch.nn as nn
    import torchvision.transforms as T
    import torchvision.models as models
    from torch.utils.data import DataLoader, Dataset

    cfg = params["transfer_learning"]
    image_size = tuple(params["prepare"]["image_size"])
    seed = params["base"]["random_seed"]
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[train] Using device: {device}")

    num_classes = len(class_map)
    idx_to_class = {v: k for k, v in class_map.items()}

    # ── Transforms ──────────────────────────────────────────────────────
    normalize = T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])

    train_tf = T.Compose([
        T.Resize((image_size[1] + 32, image_size[0] + 32)),
        T.RandomCrop(image_size),
        T.RandomHorizontalFlip(),
        T.RandomVerticalFlip(p=0.2),
        T.RandomRotation(20),
        T.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.3, hue=0.1),
        T.RandomGrayscale(p=0.05),
        T.ToTensor(),
        normalize,
    ])

    val_tf = T.Compose([
        T.Resize(image_size),
        T.ToTensor(),
        normalize,
    ])

    # ── Dataset ─────────────────────────────────────────────────────────
    class CattleDataset(Dataset):
        def __init__(self, root: Path, class_map: dict, transform=None):
            self.samples = []
            self.transform = transform
            for class_name, label_idx in class_map.items():
                class_dir = root / class_name
                if not class_dir.exists():
                    continue
                for img_path in sorted(class_dir.iterdir()):
                    if img_path.suffix.lower() in {".jpg", ".jpeg", ".png"}:
                        self.samples.append((img_path, label_idx))

        def __len__(self):
            return len(self.samples)

        def __getitem__(self, idx):
            from PIL import Image as PILImage
            path, label = self.samples[idx]
            img = PILImage.open(path).convert("RGB")
            if self.transform:
                img = self.transform(img)
            return img, label

    train_ds = CattleDataset(trans_dir / "train", class_map, train_tf)
    val_ds = CattleDataset(trans_dir / "val", class_map, val_tf)

    g = torch.Generator()
    g.manual_seed(seed)

    train_loader = DataLoader(
        train_ds, batch_size=cfg["batch_size"], shuffle=True,
        num_workers=2, pin_memory=True, generator=g
    )
    val_loader = DataLoader(
        val_ds, batch_size=cfg["batch_size"], shuffle=False,
        num_workers=2, pin_memory=True
    )
    print(f"  Train: {len(train_ds)} | Val: {len(val_ds)} | Classes: {num_classes}")

    # ── Model ──────────────────────────────────────────────────────────
    backbone_name = cfg["backbone"]
    print(f"  Loading backbone: {backbone_name}")

    if "efficientnet_b0" in backbone_name:
        model = models.efficientnet_b0(weights="IMAGENET1K_V1")
        in_features = model.classifier[1].in_features
        model.classifier = nn.Sequential(
            nn.Dropout(cfg["dropout"]),
            nn.Linear(in_features, num_classes),
        )
    elif "efficientnet_b2" in backbone_name:
        model = models.efficientnet_b2(weights="IMAGENET1K_V1")
        in_features = model.classifier[1].in_features
        model.classifier = nn.Sequential(
            nn.Dropout(cfg["dropout"]),
            nn.Linear(in_features, num_classes),
        )
    elif "resnet50" in backbone_name:
        model = models.resnet50(weights="IMAGENET1K_V2")
        in_features = model.fc.in_features
        model.fc = nn.Sequential(
            nn.Dropout(cfg["dropout"]),
            nn.Linear(in_features, num_classes),
        )
    elif "mobilenet_v3_large" in backbone_name:
        model = models.mobilenet_v3_large(weights="IMAGENET1K_V2")
        in_features = model.classifier[3].in_features
        model.classifier[3] = nn.Linear(in_features, num_classes)
    else:
        raise ValueError(f"Unknown backbone: {backbone_name}")

    # Freeze backbone for warm-up
    for name, param in model.named_parameters():
        if "classifier" not in name and "fc" not in name:
            param.requires_grad = False

    model = model.to(device)

    # ── Training helpers ────────────────────────────────────────────────
    def get_head_params():
        return [p for p in model.parameters() if p.requires_grad]

    def unfreeze_top_n(n: int):
        all_params = list(model.named_parameters())
        # Unfreeze last n params (from the end, so backbone top layers)
        for _, param in all_params[-n:]:
            param.requires_grad = True

    criterion = nn.CrossEntropyLoss(label_smoothing=cfg["label_smoothing"])

    def make_optimizer(lr_head: float, lr_backbone: float = None):
        head_params = [p for n, p in model.named_parameters()
                       if p.requires_grad and ("classifier" in n or "fc" in n)]
        backbone_params = [p for n, p in model.named_parameters()
                           if p.requires_grad and "classifier" not in n and "fc" not in n]
        if lr_backbone is not None and backbone_params:
            return torch.optim.AdamW([
                {"params": head_params, "lr": lr_head},
                {"params": backbone_params, "lr": lr_backbone},
            ], weight_decay=cfg["weight_decay"])
        return torch.optim.AdamW(head_params, lr=lr_head, weight_decay=cfg["weight_decay"])

    def evaluate_val(loader):
        model.eval()
        correct, total, val_loss = 0, 0, 0.0
        with torch.no_grad():
            for xb, yb in loader:
                xb, yb = xb.to(device), yb.to(device)
                logits = model(xb)
                val_loss += criterion(logits, yb).item() * len(xb)
                correct += (logits.argmax(1) == yb).sum().item()
                total += len(yb)
        return correct / total, val_loss / total

    history = {"epoch": [], "train_loss": [], "val_loss": [], "val_accuracy": [], "phase": []}
    best_val_acc = 0.0
    patience_counter = 0
    total_epochs = cfg["total_epochs"]
    warmup_epochs = cfg["freeze_backbone_epochs"]

    # ── Phase 1: Warm-up (head only) ────────────────────────────────────
    print(f"\n  Phase 1: Warm-up ({warmup_epochs} epochs, head only)")
    optimizer = make_optimizer(cfg["lr_head"])
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=warmup_epochs)

    for epoch in range(1, warmup_epochs + 1):
        model.train()
        running_loss, n_samples = 0.0, 0
        for xb, yb in train_loader:
            xb, yb = xb.to(device), yb.to(device)
            optimizer.zero_grad()
            loss = criterion(model(xb), yb)
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * len(xb)
            n_samples += len(xb)
        scheduler.step()
        val_acc, val_loss = evaluate_val(val_loader)
        train_loss = running_loss / n_samples
        history["epoch"].append(epoch)
        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["val_accuracy"].append(val_acc)
        history["phase"].append("warmup")
        print(f"  Warmup {epoch:2d}/{warmup_epochs} | loss={train_loss:.4f} | val_acc={val_acc:.4f}")

    # ── Phase 2: Fine-tuning (unfreeze top layers) ──────────────────────
    print(f"\n  Phase 2: Fine-tuning ({total_epochs - warmup_epochs} epochs)")
    unfreeze_top_n(cfg["unfreeze_layers"])
    optimizer = make_optimizer(cfg["lr_head"], cfg["lr_backbone"])
    fine_epochs = total_epochs - warmup_epochs
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=cfg["t_max"]
    )

    for epoch_rel in range(1, fine_epochs + 1):
        epoch = warmup_epochs + epoch_rel
        model.train()
        running_loss, n_samples = 0.0, 0
        for xb, yb in train_loader:
            xb, yb = xb.to(device), yb.to(device)
            optimizer.zero_grad()
            loss = criterion(model(xb), yb)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            running_loss += loss.item() * len(xb)
            n_samples += len(xb)
        scheduler.step()

        val_acc, val_loss = evaluate_val(val_loader)
        train_loss = running_loss / n_samples
        history["epoch"].append(epoch)
        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["val_accuracy"].append(val_acc)
        history["phase"].append("finetune")
        print(f"  Fine-tune {epoch_rel:2d}/{fine_epochs} (ep {epoch}) | "
              f"loss={train_loss:.4f} | val_acc={val_acc:.4f}")

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            patience_counter = 0
            model_dir.mkdir(parents=True, exist_ok=True)
            torch.save({
                "model_state": model.state_dict(),
                "backbone": backbone_name,
                "num_classes": num_classes,
                "class_map": class_map,
                "image_size": image_size,
                "epoch": epoch,
            }, model_dir / "model.pt")
            print(f"    ✓ Saved best model (val_acc={best_val_acc:.4f})")
        else:
            patience_counter += 1
            if patience_counter >= cfg["early_stopping_patience"]:
                print(f"  Early stopping at epoch {epoch}")
                break

    print(f"\n[train] Best val accuracy: {best_val_acc:.4f}")
    return history


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main() -> None:
    params = load_params()
    exp_type = params["experiment"]["type"]
    seed = params["base"]["random_seed"]
    set_seeds(seed)

    trans_dir = Path("data/transformed")
    model_dir = Path("models/model_artifact")
    metrics_dir = Path("metrics")
    metrics_dir.mkdir(exist_ok=True)

    with open("data/processed/class_map.json") as f:
        class_map = json.load(f)

    print(f"\n{'='*60}")
    print(f"  Experiment: {exp_type.upper()}")
    print(f"  Classes: {len(class_map)}")
    print(f"{'='*60}\n")

    if exp_type == "traditional_ml":
        history = train_traditional_ml(params, trans_dir, model_dir)
    elif exp_type == "mlp":
        history = train_mlp(params, trans_dir, model_dir, class_map)
    elif exp_type == "transfer_learning":
        history = train_transfer_learning(params, trans_dir, model_dir, class_map)
    else:
        raise ValueError(f"Unknown experiment type: {exp_type}")

    # Save training history for DVC metrics/plots
    with open(metrics_dir / "train_history.json", "w") as f:
        json.dump(history, f, indent=2)
    print(f"[train] Training history saved.")


if __name__ == "__main__":
    main()
