"""
Stage 4 – evaluate.py
Loads the trained model artifact, runs inference on the held-out test set,
computes Macro F1, per-class metrics, and generates DVC-compatible plot files.
"""
# Assisted by Claude (Anthropic)

import csv
import json
import pickle
from pathlib import Path

import numpy as np
import yaml
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    f1_score,
    top_k_accuracy_score,
)


def load_params() -> dict:
    with open("params.yaml") as f:
        return yaml.safe_load(f)


# ─── Inference helpers ────────────────────────────────────────────────────────

def predict_traditional_ml(model_dir: Path, trans_dir: Path):
    with open(model_dir / "model.pkl", "rb") as f:
        pipeline = pickle.load(f)
    test_data = np.load(trans_dir / "test_features.npz")
    X_test, y_true = test_data["X"], test_data["y"]
    y_pred = pipeline.predict(X_test)
    y_prob = pipeline.predict_proba(X_test)
    return y_true, y_pred, y_prob


def predict_mlp(model_dir: Path, trans_dir: Path):
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader, TensorDataset
    from sklearn.preprocessing import StandardScaler

    checkpoint = torch.load(model_dir / "model.pt", map_location="cpu")
    cfg = checkpoint["config"]
    input_dim = checkpoint["input_dim"]
    num_classes = checkpoint["num_classes"]
    scaler: StandardScaler = checkpoint["scaler"]

    class MLP(nn.Module):
        def __init__(self):
            super().__init__()
            layers = []
            in_dim = input_dim
            for h in cfg["hidden_sizes"]:
                layers.append(nn.Linear(in_dim, h))
                if cfg["batch_norm"]:
                    layers.append(nn.BatchNorm1d(h))
                layers.append(nn.GELU())
                layers.append(nn.Dropout(0.0))  # no dropout at inference
                in_dim = h
            layers.append(nn.Linear(in_dim, num_classes))
            self.net = nn.Sequential(*layers)

        def forward(self, x):
            return self.net(x)

    model = MLP()
    model.load_state_dict(checkpoint["model_state"])
    model.eval()

    test_data = np.load(trans_dir / "test_features.npz")
    X_test = scaler.transform(test_data["X"].astype(np.float32))
    y_true = test_data["y"]

    ds = TensorDataset(torch.tensor(X_test), torch.tensor(y_true, dtype=torch.long))
    loader = DataLoader(ds, batch_size=64, shuffle=False)

    y_pred, y_prob = [], []
    with torch.no_grad():
        for xb, _ in loader:
            logits = model(xb)
            probs = torch.softmax(logits, dim=1)
            y_pred.extend(logits.argmax(1).tolist())
            y_prob.extend(probs.tolist())

    return y_true, np.array(y_pred), np.array(y_prob)


def predict_transfer_learning(model_dir: Path, trans_dir: Path, params: dict):
    import torch
    import torch.nn as nn
    import torchvision.models as models
    import torchvision.transforms as T
    from torch.utils.data import DataLoader, Dataset
    from PIL import Image as PILImage

    checkpoint = torch.load(model_dir / "model.pt", map_location="cpu")
    backbone_name = checkpoint["backbone"]
    num_classes = checkpoint["num_classes"]
    class_map = checkpoint["class_map"]
    image_size = tuple(checkpoint["image_size"])

    # Rebuild model
    if "efficientnet_b0" in backbone_name:
        model = models.efficientnet_b0(weights=None)
        in_features = model.classifier[1].in_features
        model.classifier = nn.Sequential(
            nn.Dropout(0.0), nn.Linear(in_features, num_classes)
        )
    elif "efficientnet_b2" in backbone_name:
        model = models.efficientnet_b2(weights=None)
        in_features = model.classifier[1].in_features
        model.classifier = nn.Sequential(
            nn.Dropout(0.0), nn.Linear(in_features, num_classes)
        )
    elif "resnet50" in backbone_name:
        model = models.resnet50(weights=None)
        in_features = model.fc.in_features
        model.fc = nn.Sequential(nn.Dropout(0.0), nn.Linear(in_features, num_classes))
    elif "mobilenet_v3_large" in backbone_name:
        model = models.mobilenet_v3_large(weights=None)
        in_features = model.classifier[3].in_features
        model.classifier[3] = nn.Linear(in_features, num_classes)
    else:
        raise ValueError(f"Unknown backbone: {backbone_name}")

    model.load_state_dict(checkpoint["model_state"])
    model.eval()

    normalize = T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    val_tf = T.Compose([T.Resize(image_size), T.ToTensor(), normalize])

    class CattleTestDataset(Dataset):
        def __init__(self, root, class_map, transform):
            self.samples = []
            self.transform = transform
            for class_name, label_idx in class_map.items():
                class_dir = root / class_name
                if not class_dir.exists():
                    continue
                for img_path in sorted(class_dir.iterdir()):
                    if img_path.suffix.lower() in {".jpg", ".jpeg", ".png"}:
                        self.samples.append((img_path, label_idx))

        def __len__(self):
            return len(self.samples)

        def __getitem__(self, idx):
            path, label = self.samples[idx]
            img = PILImage.open(path).convert("RGB")
            return self.transform(img), label

    test_ds = CattleTestDataset(trans_dir / "test", class_map, val_tf)
    loader = DataLoader(test_ds, batch_size=32, shuffle=False, num_workers=0)

    y_pred, y_prob, y_true = [], [], []
    with torch.no_grad():
        for xb, yb in loader:
            logits = model(xb)
            probs = torch.softmax(logits, dim=1)
            y_pred.extend(logits.argmax(1).tolist())
            y_prob.extend(probs.tolist())
            y_true.extend(yb.tolist())

    return np.array(y_true), np.array(y_pred), np.array(y_prob)


# ─── Plot generation ──────────────────────────────────────────────────────────

def save_confusion_matrix_csv(y_true, y_pred, class_names: list, out_path: Path) -> None:
    """Save confusion matrix as CSV for dvc plots."""
    cm = confusion_matrix(y_true, y_pred)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["actual", "predicted", "count"])
        for i, actual in enumerate(class_names):
            for j, predicted in enumerate(class_names):
                if cm[i][j] > 0:
                    writer.writerow([actual, predicted, int(cm[i][j])])
    print(f"  Saved confusion matrix → {out_path}")


def save_per_class_f1_csv(y_true, y_pred, class_names: list, out_path: Path) -> None:
    """Save per-class F1 scores as CSV for dvc plots."""
    report = classification_report(y_true, y_pred, target_names=class_names, output_dict=True)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["class", "f1_score", "precision", "recall", "support"])
        for name in class_names:
            if name in report:
                r = report[name]
                writer.writerow([name, round(r["f1-score"], 4),
                                  round(r["precision"], 4),
                                  round(r["recall"], 4),
                                  int(r["support"])])
    print(f"  Saved per-class F1 → {out_path}")


# ─── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    params = load_params()
    exp_type = params["experiment"]["type"]
    eval_cfg = params["evaluate"]

    model_dir = Path("models/model_artifact")
    trans_dir = Path("data/transformed")
    metrics_dir = Path("metrics")
    plots_dir = Path("plots")
    metrics_dir.mkdir(exist_ok=True)
    plots_dir.mkdir(exist_ok=True)

    with open("data/processed/class_map.json") as f:
        class_map = json.load(f)
    class_names = sorted(class_map.keys(), key=lambda k: class_map[k])
    num_classes = len(class_names)

    print(f"\n{'='*60}")
    print(f"  Evaluating: {exp_type.upper()}")
    print(f"  Test set | {num_classes} classes")
    print(f"{'='*60}\n")

    # ── Predict ─────────────────────────────────────────────────────────
    if exp_type == "traditional_ml":
        y_true, y_pred, y_prob = predict_traditional_ml(model_dir, trans_dir)
    elif exp_type == "mlp":
        y_true, y_pred, y_prob = predict_mlp(model_dir, trans_dir)
    elif exp_type == "transfer_learning":
        y_true, y_pred, y_prob = predict_transfer_learning(model_dir, trans_dir, params)
    else:
        raise ValueError(f"Unknown experiment type: {exp_type}")

    # ── Metrics ─────────────────────────────────────────────────────────
    macro_f1 = f1_score(y_true, y_pred, average="macro")
    micro_f1 = f1_score(y_true, y_pred, average="micro")
    weighted_f1 = f1_score(y_true, y_pred, average="weighted")
    accuracy = (y_true == y_pred).mean()

    top_k = eval_cfg.get("top_k", 3)
    top_k_acc = None
    if num_classes >= top_k:
        try:
            top_k_acc = top_k_accuracy_score(y_true, y_prob, k=top_k)
        except Exception:
            pass

    print(f"  Macro F1:    {macro_f1:.4f}")
    print(f"  Micro F1:    {micro_f1:.4f}")
    print(f"  Weighted F1: {weighted_f1:.4f}")
    print(f"  Accuracy:    {accuracy:.4f}")
    if top_k_acc is not None:
        print(f"  Top-{top_k} Acc:  {top_k_acc:.4f}")

    print("\n" + classification_report(y_true, y_pred, target_names=class_names))

    # ── Save DVC metrics ─────────────────────────────────────────────────
    scores = {
        "macro_f1": round(float(macro_f1), 4),
        "micro_f1": round(float(micro_f1), 4),
        "weighted_f1": round(float(weighted_f1), 4),
        "accuracy": round(float(accuracy), 4),
        "experiment_type": exp_type,
        "num_classes": num_classes,
        "num_test_samples": int(len(y_true)),
    }
    if top_k_acc is not None:
        scores[f"top_{top_k}_accuracy"] = round(float(top_k_acc), 4)

    with open(metrics_dir / "scores.json", "w") as f:
        json.dump(scores, f, indent=2)
    print(f"\n  Saved metrics → metrics/scores.json")

    # ── Save DVC plots ────────────────────────────────────────────────────
    if eval_cfg.get("generate_confusion_matrix", True):
        save_confusion_matrix_csv(y_true, y_pred, class_names, plots_dir / "confusion_matrix.csv")

    if eval_cfg.get("generate_per_class_report", True):
        save_per_class_f1_csv(y_true, y_pred, class_names, plots_dir / "per_class_f1.csv")

    print(f"\n[evaluate] ✓ Macro F1 = {macro_f1:.4f}")


if __name__ == "__main__":
    main()
