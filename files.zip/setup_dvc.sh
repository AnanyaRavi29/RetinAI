#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# setup_dvc.sh
# Run ONCE after cloning the repo to initialize git + DVC and place your data.
# Usage: bash setup_dvc.sh
# ─────────────────────────────────────────────────────────────────────────────

set -e

echo "══════════════════════════════════════════════════"
echo "  Cattle Biometrics — DVC Setup"
echo "══════════════════════════════════════════════════"

# 1. Install dependencies
echo "[1/6] Installing Python dependencies..."
pip install -r requirements.txt --quiet

# 2. Git init (skip if already a repo)
if [ ! -d ".git" ]; then
    git init
    git add .
    git commit -m "Initial project structure"
    echo "  Git repository initialized."
else
    echo "  Git already initialized."
fi

# 3. DVC init
if [ ! -d ".dvc" ]; then
    dvc init
    git add .dvc .dvcignore
    git commit -m "DVC initialized"
    echo "  DVC initialized."
else
    echo "  DVC already initialized."
fi

# 4. Place your dataset
echo ""
echo "[2/6] DATA PLACEMENT INSTRUCTIONS"
echo "  ► Download your dataset from the Google Drive link in the assignment."
echo "  ► Place it so the structure looks like:"
echo "      data/raw/<cattle_id_1>/img1.jpg"
echo "      data/raw/<cattle_id_2>/img2.jpg"
echo "      ..."
echo ""
read -p "  Press ENTER once your data is in data/raw/ ..."

# 5. DVC track raw data
echo "[3/6] Tracking raw data with DVC..."
dvc add data/raw
git add data/raw.dvc .gitignore
git commit -m "Add raw dataset (DVC tracked)"
git tag data-v1
echo "  Tagged: data-v1"

# 6. Run the full pipeline for all 3 experiments
echo ""
echo "[4/6] Running Experiment 1: Traditional ML (HOG + SVM)..."
echo "experiment:\n  type: traditional_ml" | python -c "
import yaml, sys
with open('params.yaml') as f:
    p = yaml.safe_load(f)
p['experiment']['type'] = 'traditional_ml'
with open('params.yaml', 'w') as f:
    yaml.dump(p, f, default_flow_style=False)
"
dvc repro
dvc metrics show
git add .
git commit -m "Experiment: traditional_ml (HOG+SVM)"
git tag exp-v1-traditional-ml
echo "  Tagged: exp-v1-traditional-ml"

echo ""
echo "[5/6] Running Experiment 2: MLP..."
python -c "
import yaml
with open('params.yaml') as f:
    p = yaml.safe_load(f)
p['experiment']['type'] = 'mlp'
with open('params.yaml', 'w') as f:
    yaml.dump(p, f, default_flow_style=False)
"
dvc repro
dvc metrics show
git add .
git commit -m "Experiment: mlp (MLP on HOG features)"
git tag exp-v2-mlp
echo "  Tagged: exp-v2-mlp"

echo ""
echo "[6/6] Running Experiment 3: Transfer Learning (EfficientNet)..."
python -c "
import yaml
with open('params.yaml') as f:
    p = yaml.safe_load(f)
p['experiment']['type'] = 'transfer_learning'
with open('params.yaml', 'w') as f:
    yaml.dump(p, f, default_flow_style=False)
"
dvc repro
dvc metrics show
git add .
git commit -m "Experiment: transfer_learning (EfficientNet-B2)"
git tag exp-v3-transfer-learning
echo "  Tagged: exp-v3-transfer-learning"

echo ""
echo "══════════════════════════════════════════════════"
echo "  ✓ All 3 experiments complete!"
echo ""
echo "  Useful commands:"
echo "    dvc metrics show              — show current scores"
echo "    dvc metrics diff exp-v1-traditional-ml exp-v3-transfer-learning"
echo "    dvc plots show                — open plots in browser"
echo "    dvc plots diff exp-v1-traditional-ml exp-v3-transfer-learning"
echo "    git checkout exp-v1-traditional-ml && dvc checkout  — reproduce exp1"
echo "══════════════════════════════════════════════════"
